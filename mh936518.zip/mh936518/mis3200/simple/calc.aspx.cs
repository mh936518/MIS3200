﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mis3200_prep1a_io : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        // Take user input from textboxes and place into output labels
        lblOutput1.Text = txtInput1.Text;
        lblOutput2.Text = txtInput2.Text;

        // Example Variable declarations and initializations 
        int intTest = 0;
        decimal decTest = 0m;
        string strWelcome = "Hello 3200!";
        bool blnTest = true;

        try
        {
            // Take two numbers as inouts and store into variables (convert)
            decimal decValue1 = Convert.ToDecimal(txtInput1.Text);
            decimal decValue2 = Convert.ToDecimal(txtInput2.Text);
            decimal decResult = 0.0m;

            //Perfom addition on them: + Here are other: *, /, - 
            decResult = decValue1 + decValue2;

            //Output results to labels (convert) 
            string strStatement = "Your result is: ";
            strStatement = strStatement + decResult.ToString();
            lblResult.Text = strStatement;
        }
        catch (Exception)
        {

            // Show the user a message that helps
            lblResult.Text = "Please enter a number in the testbox(s). "; 
        }

        

    }
}