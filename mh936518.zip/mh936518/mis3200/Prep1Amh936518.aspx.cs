﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mis3200_Prep1Amh936518 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnCalculate_Click(object sender, EventArgs e)
    {
        try
        {
            // Declare and initialize variables
            decimal decInput1 = 0m;
            decimal decInput2 = 0m;
            decimal decResult = 0m;


            // Assign variables the values from the textboxes don't forget to convert) 
            decInput1 = Convert.ToDecimal(txtInput1.Text);
            decInput2 = Convert.ToDecimal(txtInput2.Text);

            // Multiply the two numbers together
            decResult = decInput1 * decInput2;

            // Display the result to the user (convert) 
            lblResult.Text = decResult.ToString();
        }
        catch (Exception)
        {
            // Handle Exception with a message to the user 
            lblResult.Text = "Please enter a number in the field(s).";
          
        } 
    }
}