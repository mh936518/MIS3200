﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mis3200_Prep1Bmh936518 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnContinue_Click(object sender, EventArgs e)
    {
        // clear the message from pervious attempts
        lblMessage.Text = "";

        // if mis3200 checkbox is selected, output a message that no registration is needed
        if (cbMIS3200.Checked == true)
        {
            lblMessage.Text = txtName.Text + " has already completed MIS 3200!";
        }
        else
        {
            // if mis 2200 and mis 2800 are not both selected, output a message that prereq are not met
            if (cbMIS2200.Checked == false || cbMIS2800.Checked == false)
            {
                lblMessage.Text = txtName.Text + " has not met the prerequisites for MIS 3200!";
            }
            else
            {
                // if mis 2200 and mis 2800 are selected, but mis 3200 is not selected
                // hide the first panel, and show the resgister panel
                pnlStart.Visible = false;
                pnlRegister.Visible = true;
            }
        }

    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        // if a selection is made, hide the register panel and output message saying 
        // NAME has been registered for SELECTION of MIS 3200 
        if (rbSection100.Checked == true)
        {
            pnlRegister.Visible = false;
            lblMessage.Text = txtName.Text + " has registered for Section 100.";
        }
        else if (rbSection101.Checked == true)
        {
            pnlRegister.Visible = false;
            lblMessage.Text = txtName.Text + " has registered for Section 101.";
        }
        else
        {
            // if neither radiobutton is selected, output a message that no selection was made
            lblMessage.Text = "No selection was made.";
        }
    }

}