﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mis3200_1A_1_1A_1mh936518 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }

    protected void btnCalculate5_Click(object sender, EventArgs e)
    {
        lblErrorMessage.Text = "";

        try
        {
            // Declare and initialize variables
            decimal decInput1 = 0m;
            decimal decInput2 = 0m;
            decimal decResult = 0m;
            decimal decResult2 = 0m;
          

            // Assign variables the values from the textboxes don't forget to convert) 
            decInput1 = Convert.ToDecimal(txtInput3.Text);
            decInput2 = Convert.ToDecimal(txtInput4.Text);
            
            // add and subtract the two numbers together
            decResult = decInput1 + decInput2;
            decResult2 = decInput1 - decInput2;
            

            // Display the result to the user (convert) 
            lblAdd.Text = decResult.ToString();
            lblSubtract.Text = decResult2.ToString();
            
        }
        catch (Exception)
        {
            // Handle Exception with a message to the user 
            lblErrorMessage.Text = "Please enter a number in the field(s).";

            lblAdd.Text = string.Empty;
            lblSubtract.Text = string.Empty;
        }
    }
}