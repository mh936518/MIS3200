﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Drawing;

public partial class mis3200_1A_1_1A_1mh936518 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }

    protected void btnCalculate_Click(object sender, EventArgs e)
    {
        lblErrorMessage.Text = "";
        try
        {
            // Declare and initialize variables
            decimal decInput1 = 0m;
            decimal decInput2 = 0m;
            decimal decInput3 = 0m;
            decimal decInput4 = 0m;
            decimal decResult = 0m;
            decimal decResult2 = 0m;
            

            // Assign variables the values from the textboxes don't forget to convert) 
            decInput1 = Convert.ToDecimal(txtInput1.Text);
            decInput2 = Convert.ToDecimal(txtInput2.Text);
            decInput3 = Convert.ToDecimal(txtInput3.Text);
            decInput4 = Convert.ToDecimal(txtInput4.Text);

            // add and subtract the two numbers together
            decResult = decInput1 * decInput2 * decInput3 * decInput4;
            decResult2 = decInput4;
                       

            // Display the result to the user (convert) 
            lblCalculation.Text = decResult.ToString("C", CultureInfo.CurrentCulture);
            lblInput4.Text = decResult2.ToString();
           
        }
        catch (Exception)
        {
            // Handle Exception with a message to the user 
           
            lblErrorMessage.ForeColor = System.Drawing.Color.Red;
            lblErrorMessage.Text = "Please double check your inputs (numbers only, on blanks)";
            
        }

    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        txtInput1.Text = string.Empty;
        txtInput2.Text = string.Empty;
        txtInput4.Text = string.Empty;
        lblInput4.Text = "x";
        lblCalculation.Text = string.Empty;
    }

    protected void txtInput3_TextChanged(object sender, EventArgs e)
    {

    }
}